//---------------------------------------------------------------------
// I/O PINS
//---------------------------------------------------------------------
#define pinLed1(f) 		f(B,1)		//Led, OUTPUT
#define pinLed2(f) 		f(B,0)		//Led, OUTPUT
#define pinSound(f)		f(B,0)		//Sound, OUTPUT
#define pinRX(f)  		f(B,2)		//RP25, UART RX, INPUT , IF CHANGED UPDATE uart_init() connect to TX
#define pinTX(f)  		f(B,3)		//RP24, UART TX, OUTPUT, IF CHANGED UPDATE uart_init()


#define pinMotor0(f)  	f(B,15)	//Front Motor, PWM1L1
#define pinMotor1(f)  	f(B,13)	//Back Motor, PWM1L2
#define pinMotor2(f)  	f(B,11)	//Left Motor, PWM1L3// 
#define pinMotor3(f)  	f(B,9)	//Right Motor, PWM2H1//Conflict I2C so need to use alternative


#include "p33FJ64MC802.h"

#include <libpic30.h>



#include "oscilator.h"

#include <pwm.h>
#include <timer.h>
#include <pwm.h>
#include <uart.h>
#include <stdio.h>
#include <adc.h>

#include <math.h>


//---------------------------------------------------------------------
// LIBS
//---------------------------------------------------------------------


#include "macroutil.h"
#include "config.h"
#include "adcutil.h"
#include "timer_dt.h"
#include "motor.h"
#include "uartutil.h"
#include "led.h"
#include "matrix.h"
#include "vector3d.h"
#include "i2cutil.h"
#include "ADXL345.h"
#include "ITG3200.h"
#include "imu.h"
#include "control.h"



//---------------------------------------------------------------------
// MAIN
//---------------------------------------------------------------------


int main (void)
{
unsigned char value;
	//Configure all ports as inputs
	TRISA = 0xFFFF; TRISB = 0xFFFF;// TRISC = 0xFFFF;



	//---------------------------------------------------------------------
	// OSCILATOR
	//---------------------------------------------------------------------
	oscilator_init();
	
	//config_load();

	//---------------------------------------------------------------------
	// STATUS (LED/SOUND)
	//---------------------------------------------------------------------


    status_init();
	STATUS(BLINK_SLOW,_ON,_ON);
	__delay_ms(10);
	STATUS_INIT;

	//---------------------------------------------------------------------
	// ADC	
	//---------------------------------------------------------------------
	
//	adc_init();
	timer_init_ms();
	
	//---------------------------------------------------------------------
	// UART
	//---------------------------------------------------------------------
	uart_init();


	printf("Uart Init Ok\n");


	//---------------------------------------------------------------------
	// I2C
	//---------------------------------------------------------------------
	i2c_init();
	printf("i2c Init Ok\n");

    ADXL345_begin();
	printf("ADXL Init Ok\n");

	ITG3200_begin();
	printf("ITG3200 Ok\n");
	//STATUS(BLINK_FAST,_ON,_ON);  
	
	printf("Init Gyro\n");

//	STATUS_NORMAL;
//__delay_ms(100);
// Acceleromter calibration
int AcclCalibration;
AcclCalibration =1;
//#define AccCali
#ifdef AccCali
while(AcclCalibration){
	int i;
	double  adjAccl;
	for(i=0;i<10;i++){
	ADXL345_update();
}
	float Acclx=getAcclXOutput();
	float Accly=getAcclYOutput();
	float Acclz=getAcclZOutput();
	float   Gravity=sqrt(Acclx*Acclx+Accly*Accly+Acclz*Acclz);
	adjAccl= 1/Gravity;
	ADXL345_Scaler =adjAccl * ADXL345_Scaler;
	printf("%1.3f %1.3f %1.3f Gravity %1.9f y %1.9f %1.3f\n",Acclx,Accly,Acclz,Gravity,ADXL345_Scaler,adjAccl);
	if (Gravity == 1.0000) AcclCalibration=0;
	}
	printf("Accelerometer Calibrated \n");
#endif

	//---------------------------------------------------------------------
	// MOTOR
	//---------------------------------------------------------------------
	motor_init();
	printf("motor init ok\n");
__delay_ms(100);

#define motor_debug
#ifdef motor_debug

//while(1){
//	_LAT(pinMotor0) = 1;
//	_LAT(pinMotor1) = 1;
//	_LAT(pinMotor2) = 1;
//	_LAT(pinMotor3) = 1;
//
//	_TRIS(pinMotor0) = 0;
//	_TRIS(pinMotor1) = 0;
//	_TRIS(pinMotor2) = 0;
//	_TRIS(pinMotor3)= 0;
//
//
//}




	int i=0;
	while(i<5){
		_LAT(pinLed1) =! _LAT(pinLed1);
		motor_set_duty(0,i);
		motor_set_duty(1,i);
		motor_set_duty(2,i);
		motor_set_duty(3,i);
		motor_apply_duty();
		__delay_ms(50);
		i = i + 1;
	//	if(i> 90) i = 0;
		printf("Motor %x \n");
	
	}
		__delay_ms(250);
		i=0;
		motor_set_duty(0,i);
		motor_apply_duty();
		motor_set_duty(1,i);
		__delay_ms(250);
		motor_apply_duty();
		motor_set_duty(2,i);
		__delay_ms(250);
		motor_apply_duty();
		motor_set_duty(3,i);
		__delay_ms(250);
		motor_apply_duty();
		__delay_ms(250);
	
	
#endif

	//---------------------------------------------------------------------
	// IMU
	//---------------------------------------------------------------------
	imu_init();
#define imu_debug
#ifdef imu_debug
	//IMU debug comment out for production
	float interval_ms=0;
	while (1){
	ITG3200_update();
	ADXL345_update();

	interval_ms = interval_ms+( timer_dt()*1000);
		
	//	printf("Time %f3\n",interval_ms);
		if(interval_ms > 5 ){
			//we have fresh adc samples
			imu_update(interval_ms);
	float	anglePitch=(atan2(dcmGyro[2][1],dcmGyro[2][2]))*180/3.14;
	float	angleRoll=-(asin(dcmGyro[2][0]))*180/3.14;
//	float	angleYaw=(-atan2(dcmGyro[1][0],dcmGyro[0][0]))*180/3.14;
	float 	driftX=(sin(anglePitch*(3.14/180))*(sin(angleRoll*(3.14/180))));
	float   CalcDriftX=getAcclXOutput()-driftX;
	float 	Acclx=getAcclXOutput();

//printf("\n");
		printf(" Angle P%1.3f R%1.3f Drift=%1.3f Acclx=%1.3f Calc=%1.3f \n",anglePitch,angleRoll,driftX,Acclx,CalcDriftX);
//if(0 == imu_sequence % 4){
//			hdlc_send_byte(float_to_int(anglePitch));
//				hdlc_send_byte(float_to_int(angleRoll));
//				hdlc_send_byte(float_to_int(driftX));
//				hdlc_send_sep();
//}
	interval_ms=0;
			
		}
}

#endif

	//---------------------------------------------------------------------
	// MAIN LOOP
	//---------------------------------------------------------------------

	#define MAX_CONTROL	10.0					//maximum control in duty cycle units 
	#define MAX_THR  (100.0-MAX_CONTROL*2)		//maximum allowed throtle 
	int controlRoll,controlPitch, controlYaw;	//control for each axis
	float Roll,Pitch,Yaw;					
	float throtle = 0;

	float RwTrg[2];								//target inclination
	float yawTrg;								//target Yaw rotation rate in  deg / ms

	
	
	while (1){
		unsigned char panic = 0;
	
		 float interval_ms;

	//	unsigned long interval_us = adc_new_data();
		float dt =  dt+ timer_dt();
		interval_ms=(float)dt;
	/*
	

		if(BATTERY_VOLTS < 9.0){ 
			STATUS_PANIC_BATTERY;
			panic = 1;
		}

*/
	//	printf(" %1.3f \n",interval_ms);
	//	if(dt > 0.020 ){		//loop running at 7.056ms see adcutil.h
			//we have fresh adc samples
			ITG3200_update();
			ADXL345_update();
			imu_update(dt);
			dt=0;
			//development safety feature, decrease throtle if inclination is too big (imminent crash)

		//	Read_Uart();
			Yaw = getGyroZOutput();	
			Pitch =	(atan2(dcmGyro[2][1],dcmGyro[2][2]))*180/3.14;
			Roll =	-(asin(dcmGyro[2][0]))*180/3.14;

			
			controlYaw = getGyroZOutput();	
			controlPitch =	(dcmGyro[2][1],dcmGyro[2][2]);
			controlRoll =	(dcmGyro[2][0]);

			throtle=10;
			motor_set_duty(0,throtle + controlYaw + controlPitch);		//FRONT
			motor_set_duty(1,throtle + controlYaw - controlPitch);		//BACK
			motor_set_duty(2,throtle - controlYaw + controlRoll);		//LEFT
			motor_set_duty(3,throtle - controlYaw - controlRoll);		//RIGHT
		//	motor_apply_duty();

				
				
	

			if(0 == imu_sequence % 4){
				//send debug data every few cycles
				//SerialChart file: PicQuadController_DEBUG_CONTROL.scc
				hdlc_send_byte(float_to_int(controlPitch));
				hdlc_send_byte(float_to_int(controlRoll));
				hdlc_send_byte(float_to_int(controlYaw));
//				hdlc_send_byte(float_to_int(anglePitch));
//				hdlc_send_byte(float_to_int(angleRoll));
//				hdlc_send_byte(float_to_int(angleYaw));
////				hdlc_send_byte(float_to_int(getAcclXOutput()));
////				hdlc_send_byte(float_to_int(getAcclYOutput()));
////				hdlc_send_byte(float_to_int(getAcclZOutput()));
				hdlc_send_sep();				
			}


		
//
//			if(0 == imu_sequence % 4){
//				//send debug data every few cycles
//				//SerialChart file: PicQuadController_MOTOR_DEBUG1.scc
//				//hdlc_send_word(interval_us);
//			
//			
//				hdlc_send_byte(motorDuty[0]);
//				hdlc_send_byte(motorDuty[1]);
//				hdlc_send_byte(motorDuty[2]);
//				hdlc_send_byte(motorDuty[3]);
//				hdlc_send_sep();
//				//printf("motor Debug\n");
//			}
			

		
//			if(0 == imu_sequence % 4){
//				//send debug data every few cycles
//				//SerialChart file: PicQuadController_TX.scc
//				hdlc_send_byte(T_Pitch);
//				hdlc_send_byte(T_Roll);
//				hdlc_send_byte(T_Yaw);
//				hdlc_send_byte(T_Throttle);
//			
//				hdlc_send_sep();
//			}
//			
		

		}
		

		
	
		
//	}



	return 0;
}

//---------------------------------------------------------------------
// THE END
//---------------------------------------------------------------------
